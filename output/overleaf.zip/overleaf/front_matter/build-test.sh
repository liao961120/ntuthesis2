
pandoc/pandoc-2.8.1/bin/pandoc \
        --output=front_matter.tex \
        --file-scope  \
        --template=template-rewrite.tex \
        --csl=ntuthesis.cls \
        front_matter.md