---
#ntu-template: 'phd' # phd, proposal
title-en: 'A Minimal NTU Thesis Pandoc Template'
title-zh: '臺灣大學論文 Pandoc 模板'
advisor-zh: |
  | 道約翰 \ \ 博士
  | \hspace{85pt} 道珍珍 \ \ 博士
## Second advisor needs to tweek hspace
advisor-en: |
  | Jonh Doe, PhD.
  | \hspace{60pt} Jane Doe, PhD.
## Second advisor needs to tweek hspace
author-en: 'Ming Wang'
author-zh: '王小明'
studentid: 'r08142002'
college-en: 'College Of Liberal Arts'
college-zh: '文學院'
year-ce: '2011'
year-mg: '100'
month-en: 'June'
month-num: '6'
day: '28'
institute-en: 'Graduate Institute of Linguistics'
institute-zh: '語言學研究所'
---

